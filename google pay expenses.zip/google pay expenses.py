# Shared Expense Manager

# Friends list
friends = ["sakthivel", "yuvaraj", "babu","manju","mydhan"]

# Dictionary to store expenses
expenses = {
    "sakthivel": 0,
    "yuvaraj": 0,
    "babu": 0,
    "manju":0,
    "mydhan":0,
}

print("==== Shared Expense Manager ====")

# Input expenses
for person in friends:
    amount = float(input(f"Enter total amount paid by {person}: ₹"))
    expenses[person] = amount

# Calculate total expense
total_expense = sum(expenses.values())

# Equal share
equal_share = total_expense / len(friends)

print("\n----- Expense Summary -----")
print("Total Expense: ₹", total_expense)
print("Each person should pay: ₹", equal_share)

# Calculate balance
balance = {}

for person in friends:
    balance[person] = expenses[person] - equal_share

print("\n----- Settlement -----")

# Find who owes whom
for person in friends:
    if balance[person] > 0:
        print(f"{person} should receive ₹{balance[person]:.2f}")
    elif balance[person] < 0:
        print(f"{person} should pay ₹{-balance[person]:.2f}")
    else:
        print(f"{person} is settled.")

print("\nDetailed Balances:", balance)